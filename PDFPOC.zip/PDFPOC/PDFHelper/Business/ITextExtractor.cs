﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDFHelper
{
   public interface ITextExtractor
    {
        string ExtractText(string path);
    }
}
