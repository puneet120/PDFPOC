﻿using PDFHelper;
using PDFHelper.Common;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace PDFPOC.Controllers
{
    public class FileUploadController : Controller
    {
        private readonly ITextExtractor _textExtractor;
        public FileUploadController(ITextExtractor textExtractor)
        {
            _textExtractor = textExtractor;
        }
        
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(HttpPostedFileBase file)
        {           
            string text = string.Empty;
            try
            {
                if (file.ContentLength == 0)
                    throw new Exception("Zero length file!");
                else
                {
                    var fileName = System.IO.Path.GetFileName(file.FileName);
                    var filePath = System.IO.Path.Combine(Server.MapPath("~/SourcePDF"), fileName);
                    file.SaveAs(filePath);
                    TempData["Message"] = "File Uploaded Successfully";
                    text = _textExtractor.ExtractText(filePath);                   
                    ViewBag.Result = text;
                    ViewData["Table"] = GetTable(filePath);
                }
            }
            catch (Exception ex)
            {
                TempData["Message"] = ex.Message.ToString();
            }

            return View();
        }

        private ConcurrentDictionary<string,string> GetTable(string path)
        {
            var pageNo = 1;
            float[] limitCoordinates = null;          
            var lineText = LineUsingCoordinates.getLineText(path, pageNo, limitCoordinates);        
            StringBuilder sb = new StringBuilder();
            foreach (var row in lineText)
            {
                if (row.Count > 1)
                {
                    for (var col = 0; col < row.Count; col++)
                    {
                        string trimmedValue = row[col].Trim();
                        if (trimmedValue != "")
                        {
                            sb.Append("|" + trimmedValue + "|");                           
                        }
                    }
                    sb.Append(Environment.NewLine);
                    
                }
            }
            string s = sb.ToString();
            string data = CommonHelper.GetBetween(s, "NOTE|", "|DESCRIPTION");
            var dict = new ConcurrentDictionary<string, string>();
            using (StringReader reader = new StringReader(data))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    line = line.Replace("||", "-");
                    line = line.Replace("|", "");
                    if (!string.IsNullOrWhiteSpace(line))
                    {
                        string[] splt = line.Split('-');
                        dict.TryAdd(splt[0], splt[1]);
                    }

                }
            }
             return dict;

        }
       
    }
}
