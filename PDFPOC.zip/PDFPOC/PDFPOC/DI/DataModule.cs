﻿using Autofac;
using PDFHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PDFPOC.DI
{
    public class DataModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<PdfContentExtractor>().As<ITextExtractor>().SingleInstance();

        }
    }
}